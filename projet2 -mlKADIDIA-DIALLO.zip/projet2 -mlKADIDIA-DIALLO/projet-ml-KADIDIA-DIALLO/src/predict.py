"""Prediction entry point used by the automatic grader."""
from pathlib import Path
import joblib
import pandas as pd

MODEL_PATH = Path(__file__).resolve().parents[1] / "models" / "model.joblib"
FEATURES = ["duration", "protocol", "dst_port", "src_bytes", "dst_bytes", "nb_packets", "nb_failed_logins", "nb_conn_same_host", "syn_rate"]


def predict(df: pd.DataFrame) -> list:
    """Return one integer (0=normal, 1=attack) for each input flow."""
    if not isinstance(df, pd.DataFrame):
        raise TypeError("df doit être un pandas.DataFrame")
    missing = set(FEATURES) - set(df.columns)
    if missing:
        raise ValueError(f"Colonnes manquantes : {sorted(missing)}")
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Modèle absent. Lance d'abord : python src/train.py")
    model = joblib.load(MODEL_PATH)
    predictions = model.predict(df[FEATURES])
    return [int(value) for value in predictions]

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Prédire les attaques d'un fichier CSV sans colonne attaque.")
    parser.add_argument("csv", help="CSV contenant les colonnes de flux réseau")
    parser.add_argument("--output", default="predictions.csv", help="Fichier de sortie")
    args = parser.parse_args()
    data = pd.read_csv(args.csv)
    data["prediction_attaque"] = predict(data)
    data[["prediction_attaque"]].to_csv(args.output, index=False)
    print(f"Prédictions enregistrées dans {args.output}")
