# Projet 2 — Détection d'attaques réseau par Machine Learning

**Étudiante : KADIDIA DIALLO**  
**Niveau : L3 — Python, pandas, scikit-learn**

## Objectif
Construire un IDS qui classe chaque flux réseau en normal (`0`) ou attaque (`1`). Les modèles comparés sont une régression logistique et une forêt aléatoire. Le prétraitement est inclus dans un `Pipeline` afin que les mêmes transformations soient appliquées à l'entraînement et à la prédiction.

## Structure
```text
projet-ml-KADIDIA-DIALLO/
├── README.md
├── requirements.txt
├── data/flux_train.csv
├── src/train.py
├── src/predict.py
├── models/model.joblib
└── reports/resultats.json
```

## Installation
Python 3.10 ou plus récent recommandé.
```bash
python -m venv .venv
# Windows : .venv\Scripts\activate
# Linux/macOS : source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Données — IMPORTANT
Le fichier `data/flux_train.csv` inclus dans ce dossier est un **jeu synthétique de démonstration**, créé uniquement pour vérifier que le code s'exécute. Il ne s'agit pas des données officielles de l'enseignant. **Avant le rendu, remplace-le par le vrai fichier `flux_train.csv` fourni pour le cours, puis relance l'entraînement.** Les résultats du jeu de démonstration ne doivent pas être présentés comme des résultats officiels.

Colonnes attendues : `duration`, `protocol`, `dst_port`, `src_bytes`, `dst_bytes`, `nb_packets`, `nb_failed_logins`, `nb_conn_same_host`, `syn_rate`, `attaque`.

## Entraînement et évaluation
À la racine du projet :
```bash
python src/train.py
```
Le script affiche les valeurs manquantes, la répartition des classes, les rapports de classification et matrices de confusion des deux modèles. Il choisit le modèle au F1 de la classe `attaque` le plus élevé sur la validation, le réentraîne sur toutes les données, puis enregistre `models/model.joblib` et `reports/resultats.json`.

## Prédire de nouveaux flux
Le CSV d'entrée doit contenir les neuf colonnes de caractéristiques, sans `attaque`.
```python
import pandas as pd
from src.predict import predict
flux = pd.read_csv("flux_a_tester.csv")
classes = predict(flux)  # liste de 0 et 1
print(classes)
```
Ou depuis le terminal :
```bash
python src/predict.py flux_a_tester.csv --output predictions.csv
```

## Résultats (à compléter après l'entraînement sur les données officielles)

**Nom / Prénom : KADIDIA DIALLO**

| Modèle | F1 (attaque) | Rappel (attaque) | Précision (attaque) |
|---|---:|---:|---:|
| Régression logistique | Voir `reports/resultats.json` après exécution | Voir rapport | Voir rapport |
| Forêt aléatoire | Voir `reports/resultats.json` après exécution | Voir rapport | Voir rapport |

**Modèle retenu et pourquoi :** le script retient automatiquement celui qui obtient le F1-score « attaque » le plus élevé sur le jeu de validation. Indiquer ici le modèle et les valeurs issues de l'entraînement sur les données officielles.

**Analyse des erreurs :** la matrice de confusion est affichée par le script. Avec l'ordre des classes `[0, 1]`, la case ligne 1/colonne 0 correspond aux faux négatifs (attaques prédites normales) et la case ligne 0/colonne 1 aux faux positifs. Les faux négatifs sont particulièrement dangereux, car une attaque peut passer inaperçue. Reporter ici les nombres mesurés sur la validation officielle.

## GitHub — exemple de 3 commits
```bash
git init
git add README.md requirements.txt .gitignore data src
git commit -m "Ajoute la structure et le code du projet"
git add models reports
git commit -m "Ajoute le modèle et les résultats d'évaluation"
git add README.md
git commit -m "Documente les résultats et l'analyse des erreurs"
```
Créer ensuite un dépôt public nommé `projet-ml-KADIDIA-DIALLO`, puis suivre les instructions GitHub pour lier le dépôt local et pousser les commits (`git remote add origin ...`, puis `git push -u origin main`). Ne pas oublier de remplacer le CSV synthétique par le fichier officiel avant le rendu.
