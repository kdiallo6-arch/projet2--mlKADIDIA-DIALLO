"""Explore, compare and train intrusion-detection models."""
from pathlib import Path
import json
import warnings
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "flux_train.csv"
MODEL_PATH = ROOT / "models" / "model.joblib"
REPORT_DIR = ROOT / "reports"
TARGET = "attaque"
NUMERIC = ["duration", "dst_port", "src_bytes", "dst_bytes", "nb_packets", "nb_failed_logins", "nb_conn_same_host", "syn_rate"]
CATEGORICAL = ["protocol"]
FEATURES = NUMERIC + CATEGORICAL


def make_pipeline(model):
    numeric_pipe = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())])
    categorical_pipe = Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("encoder", OneHotEncoder(handle_unknown="ignore"))])
    prep = ColumnTransformer([("num", numeric_pipe, NUMERIC), ("cat", categorical_pipe, CATEGORICAL)])
    return Pipeline([("preprocessing", prep), ("classifier", model)])


def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Fichier introuvable : {DATA_PATH}. Ajoute le vrai data/flux_train.csv fourni par l'enseignant.")
    df = pd.read_csv(DATA_PATH)
    missing = set(FEATURES + [TARGET]) - set(df.columns)
    if missing:
        raise ValueError(f"Colonnes manquantes dans le CSV : {sorted(missing)}")
    if df[TARGET].isna().any() or not set(df[TARGET].unique()).issubset({0, 1}):
        raise ValueError("La colonne 'attaque' doit contenir uniquement 0 et 1, sans valeurs manquantes.")

    print("=== Exploration ===")
    print(f"Dimensions : {df.shape}")
    print("Valeurs manquantes :\n", df[FEATURES].isna().sum())
    print("Répartition de attaque :\n", df[TARGET].value_counts(normalize=False).sort_index())
    print("Proportions :\n", df[TARGET].value_counts(normalize=True).sort_index().round(3))

    X, y = df[FEATURES], df[TARGET].astype(int)
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
    models = {
        "Régression logistique": make_pipeline(LogisticRegression(max_iter=2000, class_weight="balanced", random_state=42)),
        "Forêt aléatoire": make_pipeline(RandomForestClassifier(n_estimators=400, min_samples_leaf=2, class_weight="balanced", random_state=42, n_jobs=-1)),
    }
    results = {}
    best_name, best_f1 = None, -1
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    for name, pipeline in models.items():
        pipeline.fit(X_train, y_train)
        pred = pipeline.predict(X_val)
        f1 = f1_score(y_val, pred, pos_label=1, zero_division=0)
        results[name] = {
            "f1_attaque": float(f1),
            "rappel_attaque": float(recall_score(y_val, pred, pos_label=1, zero_division=0)),
            "precision_attaque": float(precision_score(y_val, pred, pos_label=1, zero_division=0)),
            "matrice_confusion": confusion_matrix(y_val, pred, labels=[0, 1]).tolist(),
            "rapport": classification_report(y_val, pred, labels=[0, 1], target_names=["normal", "attaque"], zero_division=0, output_dict=True),
        }
        print(f"\n=== {name} ===")
        print(classification_report(y_val, pred, labels=[0, 1], target_names=["normal", "attaque"], zero_division=0))
        print("Matrice de confusion (lignes=vrai, colonnes=prédit; ordre 0,1) :\n", confusion_matrix(y_val, pred, labels=[0, 1]))
        print(f"F1 attaque : {f1:.4f}")
        if f1 > best_f1:
            best_name, best_f1 = name, f1

    # Refit the selected model on all labelled training rows, as required by the assignment.
    selected = models[best_name]
    selected.fit(X, y)
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(selected, MODEL_PATH)
    report = {"note": "Mesures calculées sur la validation de ce CSV. Remplacer tout jeu synthétique par le CSV officiel avant le rendu.", "modele_retenu": best_name, "resultats_validation": results}
    (REPORT_DIR / "resultats.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nModèle retenu : {best_name}; F1 validation={best_f1:.4f}")
    print(f"Modèle sauvegardé : {MODEL_PATH}")
    print(f"Rapport sauvegardé : {REPORT_DIR / 'resultats.json'}")

if __name__ == "__main__":
    main()
